# OpenAI Codex Credential Pool

Use this when adding or maintaining multiple OpenAI OAuth accounts under the same Hermes provider.

## Goal

Keep multiple OpenAI accounts in the same `openai-codex` credential pool so Hermes can fail over when one account is exhausted or rate-limited.

## Standard workflow

1. Run `hermes auth add openai-codex`.
2. Complete the browser/device-code OAuth flow for the new account.
3. Re-run `hermes auth list openai-codex` and confirm every intended account appears in the pool.
4. If you want balanced reuse instead of filling one credential first, set `credential_pool_strategies.openai-codex = round_robin`.

## Operational notes

- Add the second account to the same provider pool; do not create a separate provider just because the email differs.
- Pool failover only helps when there are at least two healthy credentials.
- If a credential is marked exhausted after prior 429/401 handling, clear the status with `hermes auth reset openai-codex` after the account is healthy again.
- Treat OAuth tokens and device codes as secret material; never paste them into notes or skill text.

## Verification

Expected healthy state:
- `hermes auth list openai-codex` shows multiple entries.
- The intended accounts are all present.
- New logins are visible before relying on failover.
