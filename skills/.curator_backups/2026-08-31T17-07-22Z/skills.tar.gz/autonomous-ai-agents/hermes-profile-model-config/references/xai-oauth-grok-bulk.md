# xAI OAuth Grok bulk switch + Nous free fallback

Verified recipe from 2026-08-27: all Hermes profiles on `grok-4.5` / `xai-oauth`, failover to Nous free, OpenCode hidden from pickers.

## Preconditions

- `hermes auth list` shows healthy `xai-oauth` and `nous` credentials.
- Discover profiles dynamically: `ls ~/.hermes/profiles/` (plus default `~/.hermes/config.yaml`).
- `patch`/`write_file` blocked on config — use terminal + ruamel.yaml; backup each file first.

## Target shape (per profile)

```yaml
model:
  default: grok-4.5
  provider: xai-oauth
  # drop cosmetic model.name if present
  auxiliary:
    provider: xai-oauth
    vision:
      model: grok-4.5
      provider: xai-oauth
fallback_providers:
  - provider: nous
    model: tencent/hy3:free
credential_pool_strategies:
  xai-oauth: fill_first
  nous: fill_first
model_catalog:
  excluded_providers:
    - opencode
    - opencode-zen
    - opencode-go
    - opencode-free
```

## Why these choices

| Piece | Why |
|-------|-----|
| `xai-oauth` not bare `xai` | SuperGrok/Premium+ OAuth path; no `XAI_API_KEY` required |
| `grok-4.5` | User-requested primary; live on `GET /v1/models` under OAuth |
| Vision = same pair | Grok 4.5 is multimodal (text+image+pdf). Pins Telegram image reads to primary instead of leftover `stepfun/…:free` |
| Fallback `nous`/`tencent/hy3:free` | Real Nous free tier this account owns. Do **not** use bare `hy3-free` under `nous` — that id is OpenCode-free only and 404s on Nous (2026-08-30 wiki outage). OpenRouter free entries fail with no key; `opencode-free` is wrong product |
| `model_catalog.excluded_providers` | Hides built-in OpenCode family from pickers (cannot delete from Hermes source) |

## Vision confirmation (Telegram images)

- xAI model page for `grok-4.5`: modalities **Text, Image**.
- models.dev / local `models_dev_cache.json` under provider `xai`: `attachment: true`, `modalities.input: [text, image, pdf]`.
- Image understanding API accepts jpg/png, max 20MiB; content parts can mix image + text in any order.
- With vision slot + main both on grok-4.5, Telegram photo messages can be read natively. If primary is rate-limited mid-turn, text may fall to hy3-free (text-only) — image turns may still need the vision slot or wait for Grok quota.

## Bulk apply sketch (ruamel)

```python
from pathlib import Path
from datetime import datetime
import shutil
from ruamel.yaml import YAML

y = YAML(); y.preserve_quotes = True; y.indent(mapping=2, sequence=4, offset=2)
PRIMARY, PROV = 'grok-4.5', 'xai-oauth'
FALLBACK = [{'provider': 'nous', 'model': 'tencent/hy3:free'}]
EXCLUDE = ['opencode', 'opencode-zen', 'opencode-go', 'opencode-free']
files = [Path.home()/'.hermes'/'config.yaml'] + list((Path.home()/'.hermes'/'profiles').glob('*/config.yaml'))
for path in files:
    bak = path.with_suffix(path.suffix + f'.bak.{datetime.utcnow():%Y%m%dT%H%M%SZ}')
    shutil.copy2(path, bak)
    data = y.load(path) or {}
    m = data.setdefault('model', {})
    m['default'], m['provider'] = PRIMARY, PROV
    m.pop('name', None)
    aux = m.setdefault('auxiliary', {})
    aux['provider'] = PROV
    vis = aux.setdefault('vision', {})
    vis['model'], vis['provider'] = PRIMARY, PROV
    data['fallback_providers'] = FALLBACK
    data.pop('fallback_model', None)
    cps = data.setdefault('credential_pool_strategies', {})
    cps.setdefault('xai-oauth', 'fill_first')
    cps.setdefault('nous', 'fill_first')
    data.setdefault('model_catalog', {})['excluded_providers'] = list(EXCLUDE)
    y.dump(data, path)
```

## OpenCode cleanup (auth + cache)

```python
import json, shutil
from pathlib import Path
from datetime import datetime
auth = Path.home()/'.hermes'/'auth.json'
shutil.copy2(auth, auth.with_suffix(auth.suffix + f'.bak.{datetime.utcnow():%Y%m%dT%H%M%SZ}'))
d = json.loads(auth.read_text())
for k in list((d.get('credential_pool') or {})):
    if 'opencode' in k.lower():
        del d['credential_pool'][k]
auth.write_text(json.dumps(d, indent=2) + '\n')
cache = Path.home()/'.hermes'/'provider_models_cache.json'
if cache.exists():
    c = json.loads(cache.read_text())
    for k in list(c):
        if 'opencode' in k.lower():
            del c[k]
    cache.write_text(json.dumps(c))
```

## Verify

```bash
# YAML audit (include fallback + excluded)
python3 - <<'PY'
# see references/audit-and-availability-check.md extended script
PY
hermes profile list
hermes fallback list
hermes -p zeus fallback list
hermes auth list   # expect nous + xai-oauth only among usable pools
# smoke xAI chat completions with OAuth token (do not log token)
# restart gateways; if bulk restart times out, check PIDs + gateway.log Telegram healthy
```

## Pitfalls

- `hermes fallback add` is interactive — never script it; edit YAML.
- Wrong nest: `model.excluded_providers` is ignored; use `model_catalog.excluded_providers`.
- Stale OpenRouter free fallback with no API key looks fine in `hermes fallback list` until failover fires.
- Gateway multi-profile restart may exceed 180s tool timeout; verify process/log health independently.
