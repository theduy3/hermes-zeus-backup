---
name: cron-job-patterns
title: Cron Job Patterns
description: Patterns for setting up cron jobs in Hermes — timezone handling, multi-profile coordination, context chaining via filesystem, and watchdog scripts.
category: devops
---

# Cron Job Patterns

## Timezone Handling (US/CA Pacific)

When a Vancouver/Pacific-time user says a time in "PST" during DST (mid-Mar to early Nov), **clarify**:

> Vancouver is on PDT (UTC-7) right now. "5AM PST" would be 6AM your clock.
> 1. **Match your clock** — runs at 5AM local year-round (UTC-7 in summer, UTC-8 in winter)
> 2. **True PST** — UTC-8 always (runs at 6AM local in summer, 5AM in winter)

Offer both options with explicit local-clock impact so the user can choose.

**Conversion reference:**
- True PST = UTC-8 (winter standard)
- Local clock during DST = UTC-7 (PDT)
- DST in Canada: 2nd Sun Mar → 1st Sun Nov

**Key insight:** Many users say "PST" as a generic label for Pacific time even during DST. Always disambiguate.

## Cross-Profile Cron Coordination

Zeus can chain off another profile's cron output by reading its output files directly (same filesystem):

```
catthew output: ~/.hermes/profiles/<profile>/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md
```

In the downstream cron prompt, include a step like:
```
FIRST, read Catthew's latest family briefing output from the most recent file in /home/hermes/.hermes/profiles/catthew/cron/output/<job_id>/
```

For profiles that store task/reminder cron jobs, aggregate due-today/overdue items by reading their `jobs.json` directly:
```
finance tasks: ~/.hermes/profiles/finance/cron/jobs.json
investment strategist tasks: ~/.hermes/profiles/charles/cron/jobs.json
```
Include enabled jobs whose `next_run_at`/`run_at` is today in the user's Pacific timezone, plus overdue enabled one-shot jobs whose repeat has not completed. Omit that subsection when none are due. If a profile's `jobs.json` does not exist yet, treat it as no due items rather than failing the briefing.

**Important:** `context_from` only works within the **same profile's** scheduler. Cross-profile context requires filesystem reads.

## Editing Another Profile's Cron Jobs

The `cronjob` tool only manages the **current profile's** scheduler. To modify another profile:

1. Determine the target profile's cron path: `~/.hermes/profiles/<profile>/cron/jobs.json`
2. Read → edit → write the JSON directly (must match schema exactly)
3. Include `updated_at` timestamp
4. Verify the job is in the right state afterwards

## Pipeline Schedule Pattern

When chaining Job A → Job B:

1. Job A runs first (e.g. Catthew family briefing)
2. Job B runs 15 min later and reads A's output
3. Gap is intentional — ensures A's output file exists before B tries to read it

For briefing prompts that include Obsidian or cross-profile tasks, explicitly require clean, user-readable output:
- Strip wiki-link brackets: `[[Page]]` → `Page`, `[[Page|label]]` → `label`
- Strip markdown/Obsidian markup such as `#tags`, `==highlight==`, and bold/italic markers
- Do not preserve raw brackets or internal note syntax in Telegram briefings; legibility beats note fidelity
- If the user wants task/reminder items as checkboxes, use Telegram-readable checkbox lines like `☐ Task text`; do **not** emit raw Obsidian `- [ ]` syntax in Telegram unless the destination is an actual vault note
- For evening task-prep/checklist jobs, number every actionable checkbox globally with a bracket ID at the end of the line: `☐ Task text [1]`, `☐ Task text [2]`. Do not restart numbering by section. This lets Duy reply quickly with completed numbers like `done 1 3`.
- Filter out routine daily/baseline reminders from specialist profiles; they are not tasks. Include only concrete one-off actions, deadlines, appointments, bills, errands, decisions, or exceptions/escalations. For Thor/wellness especially, exclude ordinary hydration, daily meditation, sitz bath, protein target, sleep routine, and generic exercise unless tied to a special situation, appointment, travel adjustment, symptom escalation, or explicit user request.

### Split Morning Briefings

When a user says the morning briefing is too dense or wants tasks separated, split into two jobs instead of one mixed briefing:
1. **Info-only job** (e.g. 6:15AM): family/schedule context, stocks, headlines, weather, horoscope. Explicitly forbid task lists, checkboxes, overdue items, and reminders.
2. **Tasks-only job** (e.g. 2 minutes later): Obsidian tasks, Catthew tasks, finance advisor reminders, investment strategist reminders, timezone triggers. Every actionable line should be `☐ item`; omit empty sections.

If Duy says to remove stocks/news/horoscope and focus on personal life, convert the morning briefing into a **personal tasks/life-admin briefing** instead of an info briefing: exclude stocks, market data, news/headlines, AI/crypto/space, horoscope, quotes, moon phase, and generic filler; gather Catthew + Daily notes + Obsidian tasks + task-button registry + dated cross-profile reminders; output compact `Today`, `Next 7 Days`, optional `Waiting / Watch`, optional `Done / Cleared` sections.

Keep the gap short but nonzero so Telegram receives two readable messages. See `references/zeus-morning-briefing-split.md` for a concrete prompt pattern.

Use `enabled_toolsets` to restrict tools per job:
- `["web", "memory", "skills", "terminal", "file"]` - typical for briefing-type jobs
- Fewer tools = fewer input tokens per run

## Testing Cron Jobs Safely

When the user asks to test a cron job immediately:

1. Use `cronjob(action="run", job_id=...)` or `hermes --profile <profile> cron run <job_id>` to queue it for the next scheduler tick.
2. Verify with `cronjob(action="list")` or `hermes --profile <profile> cron list`; `next_run_at` should move to an immediate timestamp.
3. Wait for the scheduler tick or run `hermes --profile <profile> cron tick` only when no other tick is already running.
4. Confirm completion by checking both:
   - `last_run_at` / `last_status` changed for the job, and
   - a new file appeared under `~/.hermes/profiles/<profile>/cron/output/<job_id>/`.
5. If `next_run_at` stays in the past while `.tick.lock` is fresh and specialist subprocesses are still running, the job is in progress — wait and inspect processes/logs. Do **not** remove `.tick.lock` unless it is clearly stale and the user explicitly approves clearing it.
6. If `hermes --profile <profile> cron tick` returns with no output and the job still has the same `last_run_at` / `last_status`, treat that as **not rerun yet**. Check `hermes --profile <profile> cron status`, `.tick.lock` mtime, and running Hermes/agent processes. Tell the user the job is queued/blocked rather than implying success. Ask before clearing a fresh lock or restarting the gateway.

For cross-profile aggregation jobs, avoid unnecessary nested `hermes --profile ... chat -q` calls unless the job truly needs live reasoning from those profiles; reading their `cron/jobs.json` is faster and less likely to exceed the scheduler window. If a pipeline feeds a downstream script-only job (for example, writing a JSON sidecar that a later job sends as Telegram buttons), prefer deterministic filesystem aggregation over live specialist chats — a hung child profile can prevent the sidecar from being generated, making the downstream job appear to “work” while sending nothing useful.

### Pomodoro Schedule Reminders + Separate Task Cards

When Duy wants task delivery integrated with his time-management system, keep **schedule/Pomodoro reminders** and **actionable task cards** separate:
- Schedule reminders are one-line plain Telegram time labels with no Done/Log buttons, no task registry writes, no checkboxes, no task names, and no “what to do” instructions. Example: `🗓 12:15–12:40 — Pomodoro 5 — Admin / Finance`.
- Morning briefing `Weekday Pomodoro Schedule` is also a generic time-block template only: never append daily task titles/descriptions to any schedule line. Daily tasks belong only in `Today Tasks` / `Top 3`. In particular, keep `12:15–12:40 — Pomodoro 5 — Admin / Finance` without a trailing colon/task.
- Obsidian task cards are separate messages sourced directly from `/vault/Tasks/tasks/*.md` and may include Done buttons.
- Do not merge a Pomodoro/block reminder and a task Done button into one card.
- Do not drip overdue tasks as task cards; Duy moves overdue items himself during planning. Drip due-today tasks only.
- Specific-time events/tasks must stay fixed-time items: include them in the daily plan `Fixed` section and task cards, but do not feed them into Pomodoro reminders.

Approved Duy schedule constraints:
- Before 9:00 AM: baby/family; no normal work cards.
- 10:00–10:30 AM: brunch; protected.
- 25-minute Pomodoro work reminders between 9:00 AM and 2:45 PM.
- 2:35–2:45 PM: pickup transition; stop work.
- Around 2:45 PM onward: Victoria/family; only urgent/fixed reminders.
- Company review rotation is weekdays only: Monday SalonX, Tuesday SS/Sans Souci, Wednesday Ongles Rivieres, Thursday Ongles Maily, Friday Ongles Charlesbourg.
- Weekends: do **not** schedule or label `Company Review`; use `Investment Portfolio Review` instead for the 11:45–12:15 review block.
- Weekends: do **not** include a Pomodoro schedule in the morning briefing, and Zeus schedule-reminder scripts should stay silent. Still allow source task cards for due-today fixed/important tasks.

Pattern:
1. Generate `/vault/Tasks/planning/YYYY-MM-DD.md` before the work window from `/vault/Tasks/tasks/*.md`.
2. Add/consume task metadata fields: `time_block`, `estimated_minutes`, `energy`, `priority`, `company`; detect fixed-time metadata like `due_time`, `time`, `start_time`, body `Time:`, `Kickoff:`.
3. Run the Pomodoro schedule reminder script as script-only cron every 5 minutes (e.g. `*/5 9-20 * * *`); the script should stay silent except inside configured reminder windows.
4. Use windows like: setup 9:00–9:05; Pomodoro 1 9:05–9:30; break 9:30–9:35; Pomodoro 2 9:35–10:00; brunch 10:00–10:30; Pomodoros 3–7 through 1:55; protein 2:00; exercise/shutdown 2:15–2:35.
5. Run the due-today task-card drip separately every 10 minutes; it sends at most one source-task card with Done buttons and never sends overdue tasks.
6. Verify by checking the generated plan contains brunch, pickup transition, correct weekday company, Top 3, Pomodoro sections, `Fixed` for specific-time tasks, and No-Date Triage; then dry-run a forced Pomodoro reminder and confirm there is no inline keyboard/button output.

### Duy Thor/Zeus Daily Reminder Coordination

Zeus owns tasks, planning, and calendar sync. Thor owns wellness reminders only. Keep these systems separate in prompts and summaries.

Current preferred Thor wellness schedule (Pacific/Vancouver):
- 7:00 AM — Water 1/6.
- 8:45 AM — Morning meditation.
- 10:00 AM — Brunch water 2/6.
- 12:45 PM — Golf mobility checklist.
- 1:00 PM — Water 3/6.
- 2:00 PM — Protein drink.
- 2:15 PM — Exercise before Victoria pickup.
- 4:00 PM — Water 4/6.
- 7:00 PM — Water 5/6.
- 8:45 PM — Evening stretch.
- 10:00 PM — Water 6/6.
- 10:15 PM — Evening meditation.
- Sunday 5:00 PM — Weekly measurements.

Important correction: Thor is **not** globally silent before 9AM. Duy wants water at 7AM and meditation at 8:45AM, while avoiding a 9AM pile-up with Zeus setup. Do not reintroduce 9AM water; water 2/6 belongs at 10AM brunch.

When editing Thor from Zeus, read and write `/home/hermes/.hermes/profiles/thor/cron/jobs.json` directly, back it up first, update `schedule.expr`, `schedule.display`, `schedule_display`, `next_run_at`, and `updated_at`, then validate JSON and print the affected jobs.

### Telegram Task Button Drips

When the user wants individual Telegram task cards with Done buttons, prefer a script-only drip job. See `references/telegram-task-button-drip.md` for the full pattern.

Key defaults for Duy/Zeus:
- Read `/vault/Tasks/tasks/*.md` directly instead of relying on a briefing sidecar.
- Send at most 1 card per run.
- Use `*/10 8-23 * * *` for every 10 minutes from 8:00AM through 11:50PM local/Pacific scheduler time.
- Order cards: due today first, then overdue tasks newest-first.
- The Done callback should mark the original Obsidian task file `status: completed` and edit the Telegram message.
- Registry keys should use stable task identity (`file_path` + title + `due_date`) so Done buttons keep working across repeated cards. Duy's preference: unfinished due/overdue and waiting/watch cards should be dripped again every day until marked Done. Suppress `sent` cards only within the same local day; suppress `done` cards permanently unless the source task is intentionally recreated/reset.
- Before sending, suppress any task whose `file_path` already has a registry entry with `status: sent` for the same local day, even if the task's `due_date` changed after a calendar drag/reverse-sync; if a registry entry is `done`, reconcile the source Markdown frontmatter to `status: completed`. Use `due_date` in the callback digest if needed, but do not require due-date equality for same-day duplicate suppression.
- For event-follow cards that need live metadata (example: World Cup betting odds), add enrichment late in the send loop after duplicate-suppression checks so every cron tick does not fetch APIs for cards that will not be sent. If a card was already sent and the user requests a metadata addition, edit the existing Telegram `message_id` and store the enriched field in the registry.
- For sports odds, use an official/structured feed when possible (ESPN scoreboard often embeds DraftKings markets under `competitions[0].odds`) and include moneyline, spread, and over/under in one compact `Odds:` line. Normalize team aliases/diacritics (`Korea Republic`→`South Korea`, `Côte d’Ivoire`→`Ivory Coast`, `USA`→`United States`) before matching fixtures.

### Testing Script-Only Follow-Up Jobs

When a `no_agent=True` follow-up job reads a sidecar file and sends messages/buttons:

1. Verify the sidecar exists and is non-empty before running the follow-up job.
2. Check the script’s duplicate-suppression state (registry/cache files). A successful run may send nothing if every item is already marked `sent` or `done`.
3. For a visibility test, write a fresh unique diagnostic item to the sidecar, run the script directly once, and verify the registry records a new `message_id`.
4. If the user says they do not see the real items, regenerate the upstream sidecar from source data (not just a diagnostic item), then run the follow-up script again.
5. If the upstream cron hangs behind `.tick.lock`, inspect running child processes first. Do not clear the lock unless it is stale and the user approves.

## Pitfalls

- **Cron prompts must be self-contained** — no conversation context, no memory of previous turns
- **Cross-profile context requires filesystem** — context_from is single-profile only
- **Always `cronjob action=list` before remove/update** — never guess job IDs
- **State file is the source of truth** — for non-current profiles, edit their jobs.json directly
- **Cron `run` queues for next tick, it does not synchronously finish** — verify `last_run_at`, output files, and delivery status before telling the user the test succeeded
- **Do not clear `.tick.lock` casually** — a fresh lock can mean the scheduler is actively running the job; only clear stale locks with explicit user approval
- **Can't use `clarify` in cron** — make reasonable default choices; the job runs autonomously
