---
name: periodical-pdf-ingest
description: Ingest recurring periodical PDFs into theduyvault with source archives, semantic notes, MOC routing, and quality verification.
version: 1.0.0
metadata:
  hermes:
    tags: [vault, pdf, periodicals, finance, economist, value-line]
---

# Periodical PDF Ingest

Use this companion skill when ingesting recurring magazine/newsletter/report PDFs into theduyvault, especially *The Economist* issues and Value Line `Selection & Opinion` PDFs. This skill captures workflow lessons that complement the main wiki ingest workflow.

## Trigger

- User uploads a PDF and says “ingest this”.
- PDF is a recurring periodical, market report, magazine issue, or investment survey.
- Examples: *The Economist* full issue PDFs; Value Line `Selection & Opinion` reports.

## Core workflow

0. **Bootstrap PyMuPDF in a clean cwd (before any extract)**
   - Default Hermes `python3` often lacks `pymupdf`. Prefer a throwaway venv:
     `uv venv /tmp/econ-venv --python 3.11 && uv pip install --python /tmp/econ-venv/bin/python pymupdf`
   - **Critical:** a local `inspect.py` in the process cwd (seen at `/home/hermes/.hermes/projects/inspect.py` and sometimes `/tmp/inspect.py`) shadows stdlib `inspect` and breaks `import pymupdf` with `AttributeError: module 'inspect' has no attribute 'signature'`.
   - Always run extraction from a clean workdir with no `inspect.py` on `sys.path[0]`, e.g. `mkdir -p /tmp/econ-work && cd /tmp/econ-work && /tmp/econ-venv/bin/python script.py`. Do not run from `~/.hermes/projects` or a polluted `/tmp`.
   - See `references/economist-article-boundary-slicing.md` (PyMuPDF bootstrap) and wiki-ingest `references/economist-full-issue-operational-pitfalls.md`.

1. **Extract first, then classify**
   - Use PyMuPDF for text-based PDFs (after step 0).
   - Inspect page count, metadata, and first several page previews.
   - Identify the publication, issue date, sections, and whether the PDF is a full issue or a short report.

2. **Create source-aligned archive artifacts**
   - Copy/clean the PDF into `/vault/Attachments/` with a source-aligned name.
   - Create one normalized source archive in `/vault/Sources/YYYY-MM-DD - Source Title.md`.
   - Preserve generic upload names such as `report-4.pdf` in frontmatter as `original_filename`.
   - Include full extracted text by page when the source is a short report or when full-text browsing is useful.

3. **Distill into semantic Notes**
   - Do not leave the ingest as a source archive only.
   - Create/update durable `/vault/Notes/` pages with the user’s preferred compact-but-substantive briefings.
   - Notes should carry concrete facts, figures, actors, mechanisms, and implications, not generic one-line summaries.

4. **Route into MOCs and infrastructure**
   - Update semantic MOCs, `System/wiki-index.md`, and `System/wiki-log.md`.
   - Keep newest issue/date items at the top of dated MOC sections.
   - For public-company or investable theses, route to `14 Business MOC` and/or `15 Finance & Economics MOC` as appropriate.
   - Surface watchlist candidates in the final reply/log; do not edit the user-curated watchlist autonomously.

5. **Verify before replying**
   - Attachment exists.
   - Source archive exists and contains `original_filename` for generic uploads.
   - Created/updated Notes exist and are indexed.
   - MOCs contain exact links.
   - `wiki-log.md` contains an ingest entry.
   - For full issues, spot-check semantic quality, not just counts.

## Economist full-issue quality gate

Full Economist issues require more than structural verification. Counts can pass while article-boundary slicing is wrong. After generating article-level notes:

- Identify articles that start mid-page or share a page with neighboring articles.
- Read representative generated notes from shared pages.
- Confirm each `## Briefing` starts from the intended article, not the prior article tail, chart text, or page furniture.
- If any sample is contaminated, repair slicing before finalizing, even if every note exists and every MOC link is present.
- Report concise verification numbers to the user.

See `references/economist-boundary-quality-gate.md` and `references/economist-article-boundary-slicing.md` (page-offset slicing pitfall + fix).

## Article-boundary slicing (critical)
Never slice a full-issue PDF by **physical page number** and assign one page per article. Articles routinely share pages (a short article ends mid-page; a page carries a chart + the tail of article A + the head of article B). Page-offset slicing makes article B open with article A's closing paragraph / `■` marker — counts pass but notes are contaminated. Build the manifest from the magazine TOC, then trim each slice to its own headline→`■` end-marker boundary, joining pages when an article spans a break. The 2026-08-08 issue shipped page-offset and had to be re-extracted; treat boundary correctness as part of the quality gate, not an afterthought.

## Value Line Selection & Opinion pattern

For Value Line market reports:

- Create `Stock Market Today <Issue Date>.md` with index table, rates, inflation, liquidity, breadth, allocation, portfolio signals, and interpretation.
- Update `Economic Indicators` with the newest market/rates/inflation/breadth datapoints near the top.
- Update `15 Finance & Economics MOC`.
- If the issue includes a substantial named-company feature, create a separate company/strategy note and route it through `14 Business MOC` as well.
- If the feature presents an investable thesis, list it as `Watchlist candidates (review — not added)`.

See `references/value-line-july-24-2026-pattern.md`.

## Pitfalls

- Do not treat “PDF ingested” as complete until the vault has semantic notes, MOC links, index/log entries, and verification.
- Do not rely only on `## Briefing` presence; read samples for source-boundary correctness.
- Do not bury a substantial public-company thesis inside a generic market note.
- Do not auto-edit `System/Stock Watchlist.md`; surface candidates for user review.
- Do not run PyMuPDF from `~/.hermes/projects` (or any cwd with a local `inspect.py`); use `/tmp/econ-work` + a dedicated venv (step 0).
- After a gateway/session interrupt mid-issue, re-check vault artifacts before re-running bulk extract so you do not duplicate cleaned PDFs/article folders; resume idempotently.
