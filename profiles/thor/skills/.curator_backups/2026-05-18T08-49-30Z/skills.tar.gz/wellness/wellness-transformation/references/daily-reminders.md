# Daily Reminders — Cron Job Inventory

All times in Pacific (PDT/PST). UTC = PDT+7 / PST+8.

| # | Job ID | Name | Schedule | Time (PDT) |
|---|--------|------|----------|-------------|
| 1 | 2616b50dddac | 🧘 Meditation | 0 14 * * * | 7:00 AM |
| 2 | caabc02dabc9 | 💧 Water - Morning | 0 16 * * * | 9:00 AM |
| 3 | b7db2ca9de46 | 🛁 Sitz Bath - Morning | 0 17 * * * | 10:00 AM |
| 10 | 4ab656b26552 | 🥤 Protein Drink | 0 17 * * * | 10:00 AM |
| 4 | b76341d71354 | 💧 Water - Midday | 0 19 * * * | 12:00 PM |
| 5 | 2e5b3af69398 | 💧 Water - Afternoon | 0 22 * * * | 3:00 PM |
| 6 | 0dd08e4e07da | 💧 Water - Evening | 0 1 * * * | 6:00 PM |
| 7 | 7c74587c2e68 | 🛁 Sitz Bath - Evening | 0 3 * * * | 8:00 PM |

## Weekly

| # | Job ID | Name | Schedule | Time (PDT) |
|---|--------|------|----------|-------------|
| 8 | 9a296fe6c2aa | 📏 Weekly Measurements | 0 17 * * 0 | Sun 10:00 AM |
| 9 | 092874f2406b | 🧳 Weekly Trip Check | 0 16 * * 1 | Mon 9:00 AM |

## One-Time

| # | Job ID | Name | Scheduled |
|---|--------|------|-----------|
| — | a24035c314ee | 📏 Measurement Reminder (initial) | 2026-05-12 15:00 UTC |

## Notes

- Water reminders target 3L/day (500ml per ping, 6 glasses)
- Sitz baths: 10-15 min warm water, ideally after bowel movements. Reminders are minimum.
- Meditation: starting at 20 min, ramping to 60 min over 16 weeks
- Trip check: asks about upcoming Quebec/Montreal travel, adapts plan to travel mode
- Intake logging: user must explicitly say "Log" — cron pings are nudges only, not tracked
