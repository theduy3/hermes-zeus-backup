# Gateway Troubleshooting Reference

Diagnostic procedures for Hermes messaging gateway platform issues — Telegram polling conflicts, token resolution, profile gateway isolation, and platform connectivity verification.

---

## Profile Gateway Token Resolution

**Critical architecture point:** When a profile gateway starts via `hermes -p <name> gateway run`, the `_apply_profile_override()` function in `hermes_cli/main.py` sets `HERMES_HOME` to the profile directory. However, if the parent process (e.g., Docker entrypoint) already has `HERMES_HOME` set to the main `~/.hermes`, the profile's `.env` may not be loaded correctly.

**The fix:** Always set `HERMES_HOME` explicitly when launching profile gateways from a script:

```bash
# In entrypoint.sh or supervisor:
HERMES_HOME="$profile_dir" hermes -p "$name" gateway run >> "$log_dir/gateway.log" 2>&1 &
```

**Verification:** Check what `HERMES_HOME` a running gateway process sees:

```bash
cat /proc/<pid>/environ | tr '\0' '\n' | grep HERMES_HOME
```

The correct value for a profile gateway should be `/home/hermes/.hermes/profiles/<name>`, NOT `/home/hermes/.hermes`.

---

## Profile Without config.yaml — Silent Token Sharing

A profile that has its own `.env` with a unique `TELEGRAM_BOT_TOKEN` but NO `config.yaml` will fall back to the main config. In practice this means:

1. The gateway uses the main `~/.hermes/.env` token instead of the profile's token
2. Multiple such profiles all try to use the same bot token
3. Hermes detects "Telegram bot token already in use" and refuses to start

**Fix:** Every profile needs its own `config.yaml`. Copy from the default:

```bash
cp ~/.hermes/config.yaml ~/.hermes/profiles/<name>/config.yaml
```

Then the profile's own `.env` will be loaded properly.

---

## Telegram Polling Conflict ("terminated by other getUpdates request")

### Symptoms
- Log pattern: `Connected to Telegram (polling mode)` → 4-10 seconds → `polling conflict (1/3)` → 10s retry → `polling resumed` → repeat forever
- Conflict counter always shows `(1/3)` — never increments to 2/3 or 3/3
- Thousands of conflict lines in log (e.g., 1700+)

### Diagnostic workflow

**Step 1 — Verify token uniqueness across profiles:**

```python
import hashlib
profiles_dir = "/home/hermes/.hermes/profiles"
main_env = "/home/hermes/.hermes/.env"

# Read and hash each profile's TELEGRAM_BOT_TOKEN
# Compare hashes — they MUST all be different
for name in os.listdir(profiles_dir):
    env_path = os.path.join(profiles_dir, name, ".env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                if line.startswith("TELEGRAM_BOT_TOKEN="):
                    token = line.strip().split("=", 1)[1]
                    h = hashlib.sha256(token.encode()).hexdigest()[:16]
                    print(f"{name}: hash={h}")
```

**Step 2 — Verify tokens are valid and map to different bots:**

```python
import urllib.request, json

for name, token in tokens.items():
    url = f"https://api.telegram.org/bot{token}/getMe"
    with urllib.request.urlopen(url, timeout=10) as resp:
        data = json.loads(resp.read())
        bot = data["result"]
        print(f"{name}: @{bot['username']} (id={bot['id']})")
```

Each profile MUST map to a different bot username and ID.

**Step 3 — Check scoped lock files:**

Hermes uses machine-local lock files to prevent two local gateways from using the same bot token. Location: `~/.local/state/hermes/gateway-locks/telegram-bot-token-<sha256[:16]>.lock`

```bash
ls -la ~/.local/state/hermes/gateway-locks/
for f in ~/.local/state/hermes/gateway-locks/*.lock; do
    echo "--- $(basename $f) ---"
    python3 -c "import json; print(json.dumps(json.load(open('$f')), indent=2))"
done
```

Each lock file should have a unique `identity_hash` matching the token hash from step 1. The `pid` field should match a running gateway process.

**Step 4 — Check webhook state:**

A webhook conflicts with polling. Delete it and ensure clean state:

```python
url = f"https://api.telegram.org/bot{token}/deleteWebhook?drop_pending_updates=true"
urllib.request.urlopen(url)

# Verify
info_url = f"https://api.telegram.org/bot{token}/getWebhookInfo"
# Should show: url='', pending_update_count=0
```

**Step 5 — Compare working vs broken profiles:**

If some profiles work and others don't with identical config structure:
- Compare `.env` files: `diff ~/.hermes/profiles/working/.env ~/.hermes/profiles/broken/.env`
- Compare `config.yaml`: `diff ~/.hermes/profiles/working/config.yaml ~/.hermes/profiles/broken/config.yaml`
- Check model config: each profile needs `model.provider` and `model.default` set
- Check `max_turns` — working profiles in this environment had 60, broken had 90 (minor difference)

**Step 6 — Isolation test:**

Kill ALL profile gateways, then restart only ONE broken profile alone. If it still gets conflicts when it's the only process using that token, the issue is upstream (possibly a bug in the Telegram adapter's polling session management).

```bash
# Kill all profile gateways
ps aux | grep "hermes.*-p.*gateway" | grep -v grep | awk '{print $2}' | xargs kill
sleep 3

# Delete token-scoped lock files for the target profile
rm -f ~/.local/state/hermes/gateway-locks/telegram-bot-token-<hash>.lock
rm -f ~/.hermes/profiles/<name>/gateway.lock

# Wait for Telegram to clear stale long-poll sessions
sleep 30

# Start only the target profile
hermes -p <name> gateway run

# Monitor
tail -f ~/.hermes/profiles/<name>/logs/gateway.log | grep -E "conflict|Connected|Error"
```

### Interpretation

- If the isolation test still produces conflicts → likely an upstream bug in the hermes-agent Telegram adapter. File an issue with reproduction steps.
- If the isolation test works but re-adding more profiles reintroduces conflicts → token sharing between profiles (check steps 1-2 again).
- If `hermes gateway status` shows `running` but logs show NO polling conflicts for some profiles and thousands for others → token resolution mismatch (profile using wrong `.env`).

### Step 7 — External process detection (final isolation)

If all of the above checks pass (unique tokens, valid bots, clean webhooks, proper HERMES_HOME) but conflicts persist, an external process outside the current machine may be polling the same bot token. This is common when migrating profiles from a local machine to a VPS — both instances fight over the same Telegram bot tokens.

**Test:** Kill the hermes gateway for the suspect profile, then run a minimal Python getUpdates long-poll:

```python
import urllib.request, json, time

with open(f"/home/hermes/.hermes/profiles/{name}/.env") as f:
    for line in f:
        if line.startswith("TELEGRAM_BOT_TOKEN="):
            token = line.strip().split("=", 1)[1]
            break

offset = 0
start = time.time()
while time.time() - start < 20:
    url = f"https://api.telegram.org/bot{token}/getUpdates?offset={offset}&timeout=10"
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
            if not data.get("ok"):
                print(f"ERROR: {data}")
                break
    except urllib.error.HTTPError as e:
        if e.code == 409:
            print(f"HTTP 409 Conflict — another process IS polling this token from outside")
        break
    except Exception as e:
        print(f"Exception: {e}")
        break

if time.time() - start >= 19:
    print("No conflict — token is free")
```

- If this test gets **HTTP 409**: another process elsewhere is polling the token. Check the user's other machines (macOS, other VPS, cloud deployments).
- If this test runs **clean for 20+ seconds**: the token is free, and the hermes gateway should be able to poll without issues.

**Resolution for external conflicts:**
- Stop the conflicting instance on the other machine, OR
- Generate new bot tokens via @BotFather for one of the instances, OR
- Designate which machine owns each profile (e.g., specialist agents on macOS, business profiles on VPS)

---

## Discord Platform Configuration

Discord requires only `DISCORD_BOT_TOKEN` in the profile's `.env`. The gateway auto-detects the token and connects — no `hermes gateway setup` needed. The `hermes config` display shows `Discord: not configured` when the token is missing.

To configure:
1. Add `DISCORD_BOT_TOKEN=<token>` to the profile's `.env`
2. Restart the profile gateway (with `HERMES_HOME` set to the profile path)

After restart, the log should show:
```
[Discord] Connected as <BotName>#NNNN
✓ discord connected
Gateway running with 2 platform(s)
```

### Writing to .env files

Some `.env` files are protected from file-edit tools (the `patch` tool may silently fail). When adding tokens, prefer terminal append:

```bash
echo 'DISCORD_BOT_TOKEN=<token>' >> ~/.hermes/profiles/<name>/.env
```

---

## Auxiliary Model Resolution

When the main model uses one provider (e.g., DeepSeek) but auxiliary tasks (session search, compression, vision) have `provider: auto`, they may fall back to a different provider (e.g., OpenRouter). This causes confusing 402 errors when the fallback provider has no credits.

**Fix:** Set auxiliary providers explicitly in `config.yaml`:

```yaml
auxiliary:
  session_search:
    provider: deepseek
    model: deepseek-v4-pro
    base_url: https://api.deepseek.com/v1
  compression:
    provider: deepseek
    model: deepseek-v4-pro
    base_url: https://api.deepseek.com/v1
```

---

## Quick Health Checks

```bash
# Overall gateway status
hermes gateway status

# Per-profile gateway status
hermes -p <name> gateway status

# Check for polling conflicts (broken profiles)
for p in <list>; do
    count=$(grep -c "polling conflict" ~/.hermes/profiles/$p/logs/gateway.log 2>/dev/null || echo 0)
    echo "$p: $count conflicts"
done

# Check for network errors in any profile log
grep -l "TimedOut\|ConnectError\|NetworkError" ~/.hermes/profiles/*/logs/gateway.log

# Verify token scoped locks are healthy
ls ~/.local/state/hermes/gateway-locks/
```
