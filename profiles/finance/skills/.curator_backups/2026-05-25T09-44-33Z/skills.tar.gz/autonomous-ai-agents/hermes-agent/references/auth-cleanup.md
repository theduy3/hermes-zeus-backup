# Auth Provider Cleanup

How to remove unused auth providers so only the ones you use show up.

## Quick steps for the common case

```bash
# Log out of OAuth providers (supports: nous, openai-codex, spotify)
hermes logout --provider nous
hermes logout --provider openai-codex

# Remove API-key credentials
hermes auth remove <provider> <index>
```

## Cleaning auth.json

`~/.hermes/auth.json` tracks credential pools and suppressed sources. Even after `hermes logout` and `hermes auth remove`, empty arrays and stale suppressed_sources may persist. Edit the file to keep only providers you use.

Example — keep only deepseek:
```json
{
  "version": 1,
  "providers": {},
  "credential_pool": {
    "deepseek": [ ... ]
  },
  "suppressed_sources": {}
}
```

Remove empty credential_pool entries (openrouter, anthropic, openai-codex, etc.) and clear suppressed_sources.

## Google Gemini OAuth

Tokens are stored in `~/.hermes/auth/google_oauth.json` (and its `.lock` companion file). `hermes logout` does NOT support google — remove manually:

```bash
rm ~/.hermes/auth/google_oauth.json ~/.hermes/auth/google_oauth.json.lock
```

If owned by root (from a prior docker/gateway run), use `sudo rm`.

## Providers that can't be removed from status

`hermes status --all` auto-detects these OAuth providers and always shows them as available, even when not configured:
- Nous Portal
- OpenAI Codex
- Qwen OAuth
- MiniMax OAuth

They're hardcoded in Hermes's status display — not stored credentials, not suppressible via config. Removing them requires source patches that get overwritten on updates. The best you can do is log out and clean auth.json so they show "not logged in" rather than error states.
