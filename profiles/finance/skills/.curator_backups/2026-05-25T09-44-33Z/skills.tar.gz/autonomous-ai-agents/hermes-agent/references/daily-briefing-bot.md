# Daily Briefing Bot

Docs guide: https://hermes-agent.nousresearch.com/docs/guides/daily-briefing-bot

## Pattern

A cron job that runs daily, loads the Obsidian vault for tasks/watchlist, fetches live data (news, weather, stocks, moon phase, horoscope), and delivers a formatted briefing to Telegram.

## Setup Recipe

1. Ask the user for: timezone + preferred time, delivery target, and content template
2. Convert time to UTC for the cron schedule
3. List delivery targets via `send_message(action='list')` to confirm
4. Create with: `web` + `memory` + `skills` toolsets, `obsidian` skill loaded
5. Offer a test run immediately

## Cron Job Configuration

```
Schedule: "0 14 * * *"          # 7AM PST = 14:00 UTC
Delivery: "telegram"             # or telegram:username for DM
Skills:   ["obsidian"]
Toolsets: ["web", "memory", "skills"]
```

## Briefing Template (10 sections)

```markdown
# Daily Briefing: [Day], YYYY-MM-DD
**Week N of YYYY** | **[lunar date]** | Victoria is **X weeks + X days** old
> "Quote here." — Author

## Moon Phase
[fraction] [phase] (X% illuminated, Day X.X of 29.5)

## Stock Watchlist
[Table from Obsidian: Stock Watchlist.md]
Ticker | Price | Chg % | 52W Range | P/E (fwd) | Mkt Cap | Target (upside)

## Tasks
### Overdue
### Due Today
### This Week
### Next Week
### Later / No Date
[Tasks as Obsidian wiki-link checkboxes with tags: salon360, finance, admin, stock, product, urgent]

## Morning Brew
[5-8 headlines from morningbrew.com with one-line summaries]

## Finance News
[5-10 finance/business headlines with sources and dates]

## Earnings Reports
[Any major earnings from watchlist stocks this week]

## Horoscope
[Sagittarius horoscope for today]

## Weather Forecast (7-Day)
### Vancouver, BC
### Laval, QC
### Quebec, QC
[Date | High | Low | Conditions tables]

*Generated: YYYY-MM-DD HH:MM*
```

## Data Sources

| Section | Source |
|---------|--------|
| Tasks | Obsidian vault (`obsidian` skill) |
| Stock Watchlist | `Stock Watchlist.md` in Obsidian vault |
| Moon Phase | Web lookup |
| Morning Brew | morningbrew.com/daily |
| Finance News | Web search |
| Horoscope | Cafe Astrology or similar |
| Weather | Web lookup (3 cities: Vancouver, Laval, Quebec) |

## Known Issues

- The cron agent runs in a Linux container; macOS vault paths like `/Users/theduy/theduyvault` aren't accessible. VPS deployments use `/root/theduyvault` instead. The obsidian skill picks up the active vault path from memory/config.
- If the `obsidian` skill can't reach the vault, the task/watchlist sections will be empty.
- Stock data from Yahoo Finance is delayed ~15-20 minutes.
