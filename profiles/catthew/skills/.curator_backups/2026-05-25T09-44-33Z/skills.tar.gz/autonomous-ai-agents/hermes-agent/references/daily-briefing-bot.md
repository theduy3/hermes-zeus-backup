# Daily Briefing Bot

Docs guide: https://hermes-agent.nousresearch.com/docs/guides/daily-briefing-bot

## Pattern

A cron job that runs daily, loads the Obsidian vault for tasks/watchlist, fetches live data (news, weather, stocks, moon phase, horoscope), and delivers a formatted briefing to Telegram.

## Setup Recipe

1. Ask the user for: timezone + preferred time, delivery target, and content template
2. Convert time to UTC for the cron schedule (e.g., 7AM PST = 14:00 UTC → `"0 14 * * *"`)
3. List delivery targets via `send_message(action='list')` to confirm
4. Create with CLI: `hermes cron create "0 14 * * *" "$(cat /tmp/prompt.txt)" --name "Daily Morning Briefing" --skill obsidian --deliver telegram`
5. **Add toolsets manually**: the CLI lacks `--toolsets`. After creation, edit `~/.hermes/cron/jobs.json` (or profile path) and add `"enabled_toolsets": ["web", "memory", "skills", "terminal", "file"]` to the job entry.
6. Offer a test run: `hermes cron run <job_id>`

## Cron Job Configuration

```
Schedule: "0 14 * * *"          # 7AM PST = 14:00 UTC
Delivery: "telegram"
Skills:   ["obsidian"]
Toolsets: ["web", "memory", "skills", "terminal", "file"]
```

## Briefing Template (7 compact sections)

```markdown
## 1. HEADER
"# 📅 [Day], [YYYY-MM-DD] · W[week] · Victoria: [age]"
Moon phase icon + name. One relevant quote (≤1 line).

## 2. STOCKS
Compact — only tickers that moved >2%, plus VIX/TNX.
Single line per ticker: `TICKER $price (chg%)` — no table. Max 8 tickers.

## 3. TASKS
⚠️ Overdue (max 3): wiki-link only
📌 Today (max 3): wiki-link only
📅 This Week (max 3): wiki-link only
Skip Later/No Date.

## 4. HEADLINES
Merge Morning Brew + finance into 5-6 one-line bullets. No sources, no dates.

## 5. WEATHER
Single compact table — 3 cities × today+tomorrow only:
`City | Today Hi/Lo Cond | Tomorrow Hi/Lo Cond`

## 6. HOROSCOPE
Sagittarius: 1-2 sentences max.

## 7. FOOTER
"Generated [HH:MM]"

No earnings section. Tone: tight, informative, scannable.
```

## Data Sources

| Section | Source |
|---------|--------|
| Tasks | Obsidian vault (`obsidian` skill) |
| Stock Watchlist | `Stock Watchlist.md` in Obsidian vault |
| Moon Phase | Web lookup |
| Morning Brew | morningbrew.com/daily |
| Finance News | Web search |
| Horoscope | Cafe Astrology or similar |
| Weather | Web lookup (3 cities: Vancouver, Laval, Quebec) |

## Vault Access (Docker / VPS)

- The cron agent runs in a Linux container. macOS vault paths like `/Users/theduy/theduyvault` are not accessible.
- **Docker**: the vault is typically mounted read-only at `/vault/`. Cron jobs that need to write (e.g., daily summaries) should write to writable container paths like `~/.hermes/daily-summaries/`, NOT the vault mount.
- **VPS**: the vault may be at `/root/theduyvault` or another path — check the `obsidian` skill config.
- **Read-only mount**: if the vault is `ro`, the obsidian skill can still read tasks/watchlist but cannot create or update notes.

## Moving Cron Jobs Between Profiles

The CLI has no `--profile` flag for cron operations and no built-in migration. Manual pattern:

1. **Capture the source job**: read `~/.hermes/cron/jobs.json` (or profile path), find the job entry, copy the full JSON.
2. **Create on target profile**: `hermes -p <target> cron create "<schedule>" "$(cat /tmp/prompt.txt)" --name "<name>" --skill <skill> --deliver <target>`
3. **Patch toolsets**: the CLI `create` lacks `--toolsets`. Edit `~/.hermes/profiles/<target>/cron/jobs.json` and add `"enabled_toolsets": [...]` to the job entry.
4. **Remove from source**: use the `cronjob` tool or `hermes cron remove <id>`.
5. **Verify**: `hermes -p <target> cron list`

## Known Issues

- Stock data from Yahoo Finance is delayed ~15-20 minutes.
- If the `obsidian` skill can't reach the vault, task/watchlist sections will be empty.
- Gateway must be running for jobs to fire: `hermes -p <profile> gateway status`
