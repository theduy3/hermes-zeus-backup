# Discord Profile Migration (from Telegram)

Complete workflow for switching an existing Hermes profile from Telegram to Discord
on a Docker/VPS deployment.

## When to use
- Moving business profiles (salons, etc.) from Telegram to Discord
- Profile already has DISCORD_BOT_TOKEN in .env but is connecting to Telegram
  because TELEGRAM_BOT_TOKEN is also present (Hermes picks Telegram first)

## Steps

### 1. Strip Telegram from profile .env
```bash
sed -i '/^TELEGRAM_/d' ~/.hermes/profiles/<name>/.env
```
Verify: `grep -c DISCORD ~/.hermes/profiles/<name>/.env` should be 1,
`grep -c TELEGRAM` should be 0.

### 2. Remove TELEGRAM_HOME_CHANNEL from profile config.yaml
```bash
sed -i '/^TELEGRAM_HOME_CHANNEL:/d' ~/.hermes/profiles/<name>/config.yaml
```

### 3. Kill the old gateway process
Find the PID: `ps aux | grep "hermes.*-p <name>.*gateway"`
```bash
kill <pid>       # try SIGTERM first
sleep 2
kill -9 <pid>    # if still alive, SIGKILL
```
**Pitfall**: In Docker, killed processes may show as `[hermes] <defunct>` (zombie).
This is normal — tini (PID 1) reaps them. The old process is dead; proceed.

### 4. Restart with HERMES_HOME isolation
```bash
HERMES_HOME="$HOME/.hermes/profiles/<name>" hermes -p <name> gateway run
```
**Critical**: Without `HERMES_HOME` set, the profile gateway inherits the main
`~/.hermes/.env` token. Use background mode or `&` for long-running gateways.

### 5. Verify
```bash
# Check it's running
ps aux | grep "hermes.*-p <name>.*gateway"

# Check logs for Discord connection
grep -E "Discord.*Connected|Gateway running" ~/.hermes/profiles/<name>/logs/gateway.log | tail -3
```
Expected output:
```
[Discord] Connected as BotName#NNNN
Gateway running with 1 platform(s)
```
No mention of Telegram in the log output means success.

## Docker entrypoint fix

If the container entrypoint launches profile gateways, it must set `HERMES_HOME`
per profile to prevent token inheritance:

```bash
# WRONG — all profiles inherit main ~/.hermes/.env token
hermes -p "$name" gateway run >> "$log_dir/gateway.log" 2>&1 &

# CORRECT — each profile reads its own .env
HERMES_HOME="$p" hermes -p "$name" gateway run >> "$log_dir/gateway.log" 2>&1 &
```

## Post-migration: allowlists

After switching to Discord, the gateway may warn:
```
No user allowlists configured. All unauthorized users will be denied.
```
Configure Discord-specific allowlists or set `GATEWAY_ALLOW_ALL_USERS=true`
in the profile's `.env` to accept messages from server members.
